const metricsEl = document.getElementById('metrics');
const switcherEl = document.getElementById('session-switcher');
const breakBanner = document.getElementById('break-banner');
const breakText = document.getElementById('break-text');
const breakBtn = document.getElementById('break-btn');
const themeToggle = document.getElementById('theme-toggle');

let sessions = [];
let activeSession = 'work';
let lastData = null;

// ---- Theme -------------------------------------------------------------
let isLight = false;
themeToggle.addEventListener('click', () => {
  isLight = !isLight;
  document.body.classList.toggle('light', isLight);
  themeToggle.textContent = isLight ? '☀️' : '🌙';
});

// ---- Pomodoro (client-side timer, persists while app is open) ----------
const POMODORO_WORK_SEC = 25 * 60;
const POMODORO_BREAK_SEC = 5 * 60;
let pomodoroSecondsLeft = POMODORO_WORK_SEC;
let pomodoroPhase = 'work'; // 'work' | 'break'
let pomodoroRunning = false;
let pomodoroInterval = null;

function formatMMSS(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function pomodoroTick() {
  pomodoroSecondsLeft -= 1;
  if (pomodoroSecondsLeft <= 0) {
    pomodoroPhase = pomodoroPhase === 'work' ? 'break' : 'work';
    pomodoroSecondsLeft = pomodoroPhase === 'work' ? POMODORO_WORK_SEC : POMODORO_BREAK_SEC;
  }
  if (lastData) renderMetrics(lastData);
}

function pomodoroStart() {
  if (pomodoroRunning) return;
  pomodoroRunning = true;
  pomodoroInterval = setInterval(pomodoroTick, 1000);
}

function pomodoroPause() {
  pomodoroRunning = false;
  clearInterval(pomodoroInterval);
}

function pomodoroReset() {
  pomodoroPause();
  pomodoroPhase = 'work';
  pomodoroSecondsLeft = POMODORO_WORK_SEC;
  if (lastData) renderMetrics(lastData);
}

// ---- Color helpers -------------------------------------------------------

function barClass(pct) {
  if (pct >= 85) return 'danger';
  if (pct >= 65) return 'warn';
  return '';
}

function pingClass(ms) {
  if (ms === null) return '';
  if (ms >= 150) return 'danger';
  if (ms >= 60) return 'warn';
  return 'good';
}

function batteryClass(pct) {
  if (pct <= 20) return 'danger';
  if (pct <= 45) return 'warn';
  return 'good';
}

// ---- Row builders --------------------------------------------------------

function renderRow(label, valueHtml, extraClass = '') {
  return `<div class="metric-row ${extraClass}"><span class="metric-label">${label}</span>${valueHtml}</div>`;
}

function renderBar(pct) {
  return `<div style="display:flex;align-items:center;">
    <span class="metric-value">${pct}%</span>
    <div class="bar-bg"><div class="bar-fill ${barClass(pct)}" style="width:${pct}%"></div></div>
  </div>`;
}

function renderPomodoroRow() {
  const phaseLabel = pomodoroPhase === 'work' ? 'Focus' : 'Break';
  return `
    <div class="metric-row pomodoro-row">
      <div class="pomodoro-top">
        <span class="metric-label">Pomodoro — ${phaseLabel}</span>
        <span class="pomodoro-time">${formatMMSS(pomodoroSecondsLeft)}</span>
      </div>
      <div class="pomodoro-controls">
        <button id="pomo-toggle">${pomodoroRunning ? 'Pause' : 'Start'}</button>
        <button id="pomo-reset" class="secondary">Reset</button>
      </div>
    </div>`;
}

function renderWordCountRow(count) {
  return `
    <div class="metric-row word-count-row">
      <div class="word-count-top">
        <span class="metric-label">Word Count (clipboard)</span>
        <button class="word-count-reset" id="word-count-reset">Reset</button>
      </div>
      <span class="metric-value" style="font-size:16px;">${count} words</span>
    </div>`;
}

function renderMetrics(data) {
  lastData = data;
  let html = '';

  if (data.cpu !== undefined) html += renderRow('CPU', renderBar(data.cpu));
  if (data.ram) html += renderRow('RAM', renderBar(data.ram.usedPct) + `<span style="font-size:10px;color:var(--text-dim);margin-left:4px;">${data.ram.usedGb}/${data.ram.totalGb}GB</span>`);

  if (data.battery) {
    const charging = data.battery.charging ? ' ⚡' : '';
    const cls = batteryClass(data.battery.percent);
    const timeStr = data.battery.timeRemaining && data.battery.timeRemaining > 0
      ? ` (${Math.floor(data.battery.timeRemaining / 60)}h ${data.battery.timeRemaining % 60}m left)`
      : '';
    html += renderRow('Battery', `<span class="metric-value ${cls}">${data.battery.percent}%${charging}${timeStr}</span>`);
  }

  if (data.activeApp !== undefined) html += renderRow('Active App', `<span class="metric-value">${data.activeApp}</span>`);
  if (data.network) html += renderRow('Network', `<span class="metric-value">↓${data.network.downKbps} ↑${data.network.upKbps} KB/s</span>`);
  if (data.gpu !== undefined) html += renderRow('GPU', `<span class="metric-value">${data.gpu === 'N/A' ? 'N/A' : data.gpu + '%'}</span>`);
  if (data.fanSpeed !== undefined) html += renderRow('Fan Speed', `<span class="metric-value">${data.fanSpeed}</span>`);
  if (data.uptime !== undefined) html += renderRow('Uptime', `<span class="metric-value">${data.uptime}</span>`);
  if (data.topProcess) html += renderRow('Top Memory Process', `<span class="metric-value">${data.topProcess.name} (${data.topProcess.memMb}MB)</span>`);
  if (data.timeUntil5pm !== undefined) html += renderRow('Until 5pm', `<span class="metric-value">${data.timeUntil5pm}</span>`);
  if (data.ping !== undefined) html += renderRow('Ping', `<span class="metric-value ${pingClass(data.ping)}">${data.ping === null ? 'N/A' : data.ping + ' ms'}</span>`);
  if (data.memoryPressure !== undefined) html += renderRow('Memory Pressure', `<span class="metric-value">${data.memoryPressure}</span>`);
  if (data.fps !== undefined) html += renderRow('FPS', `<span class="metric-value">${data.fps}</span>`);
  if (data.volume !== undefined) html += renderRow('Volume', `<span class="metric-value">${data.volume}</span>`);
  if (data.music !== undefined) html += renderRow('Now Playing', `<span class="metric-value">${data.music}</span>`);

  if (SESSIONS_HAS_POMODORO(data)) html += renderPomodoroRow();
  if (data.wordCount !== undefined) html += renderWordCountRow(data.wordCount);

  metricsEl.innerHTML = html;

  // Wire up dynamic buttons after innerHTML replace
  const pomoToggle = document.getElementById('pomo-toggle');
  if (pomoToggle) pomoToggle.addEventListener('click', () => { pomodoroRunning ? pomodoroPause() : pomodoroStart(); renderMetrics(lastData); });
  const pomoReset = document.getElementById('pomo-reset');
  if (pomoReset) pomoReset.addEventListener('click', pomodoroReset);
  const wcReset = document.getElementById('word-count-reset');
  if (wcReset) wcReset.addEventListener('click', () => window.api.resetWordCount());

  // Tray title
  if (data.cpu !== undefined) window.api.setTrayTitle(`${data.cpu}%`);
  else if (data.battery) window.api.setTrayTitle(`${data.battery.percent}%`);

  if (data.breakReminder) {
    if (data.breakReminder.dueForBreak) {
      breakBanner.classList.remove('hidden');
      breakText.textContent = `${data.breakReminder.minutesSinceBreak} min since your last break`;
    } else {
      breakBanner.classList.add('hidden');
    }
  } else {
    breakBanner.classList.add('hidden');
  }
}

// Pomodoro only shows for the 'work' session — checked via which session is active
function SESSIONS_HAS_POMODORO(data) {
  return data.session === 'work';
}

function renderSwitcher() {
  switcherEl.innerHTML = sessions.map(s =>
    `<div class="session-btn ${s.key === activeSession ? 'active' : ''}" data-key="${s.key}">${s.label}</div>`
  ).join('');

  switcherEl.querySelectorAll('.session-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      activeSession = btn.dataset.key;
      window.api.switchSession(activeSession);
      renderSwitcher();
    });
  });
}

async function init() {
  sessions = await window.api.getSessions();
  activeSession = await window.api.getCurrentSession();
  renderSwitcher();

  window.api.onMetrics((data) => { renderMetrics(data); });

  breakBtn.addEventListener('click', () => {
    window.api.resetBreakTimer();
    breakBanner.classList.add('hidden');
  });
}

init();
