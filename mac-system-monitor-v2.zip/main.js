const { app, Tray, Menu, BrowserWindow, ipcMain, nativeImage, clipboard } = require('electron');
const path = require('path');
const { exec } = require('child_process');
const si = require('systeminformation');

let tray = null;
let win = null;
let pollTimer = null;

// ---- Session profiles -----------------------------------------------------
const SESSIONS = {
  work: {
    label: 'Work',
    metrics: ['cpu', 'ram', 'battery', 'activeApp', 'network', 'breakReminder', 'fanSpeed', 'uptime', 'topProcess', 'pomodoro', 'timeUntil5pm'],
    refreshMs: 3000,
    breakIntervalMin: 60
  },
  gaming: {
    label: 'Gaming',
    metrics: ['cpu', 'ram', 'battery', 'activeApp', 'gpu', 'fanSpeed', 'ping', 'memoryPressure', 'fps'],
    refreshMs: 1000
  },
  chill: {
    label: 'Chill',
    metrics: ['battery', 'network', 'volume', 'music', 'wordCount'],
    refreshMs: 5000
  }
};

let currentSessionKey = 'work';
let lastBreakAt = Date.now();

// Word count tracker state (persists until manually reset)
let lastClipboardText = clipboard.readText() || '';
let wordCountTotal = 0;

// ---- Shell helpers -----------------------------------------------------

function run(cmd, timeoutMs = 1500) {
  return new Promise((resolve) => {
    exec(cmd, { timeout: timeoutMs }, (err, stdout) => {
      if (err) return resolve(null);
      resolve(stdout.trim());
    });
  });
}

function getActiveAppName() {
  const script = 'tell application "System Events" to get name of first application process whose frontmost is true';
  return run(`osascript -e '${script}'`).then(out => out || 'Unknown');
}

function getVolume() {
  const script = 'output volume of (get volume settings)';
  return run(`osascript -e '${script}'`).then(out => (out ? `${out}%` : 'N/A'));
}

function getMusicNowPlaying() {
  const script = `
    tell application "Music"
      if player state is playing then
        set trackName to name of current track
        set trackArtist to artist of current track
        return trackName & " — " & trackArtist
      else
        return "Not playing"
      end if
    end tell
  `;
  return run(`osascript -e '${script}'`, 1500).then(out => out || 'Music app not running');
}

function getPing() {
  return run('ping -c 1 -t 1 8.8.8.8').then(out => {
    if (!out) return null;
    const match = out.match(/time=([\d.]+)/);
    return match ? Math.round(parseFloat(match[1])) : null;
  });
}

function getMemoryPressure() {
  return run('memory_pressure').then(out => {
    if (!out) return 'N/A';
    const freeMatch = out.match(/System-wide memory free percentage:\s*(\d+)%/);
    if (freeMatch) return `${freeMatch[1]}% free`;
    return 'N/A';
  });
}

function getFanSpeed() {
  // Best-effort only — macOS does not expose fan RPM without sudo/extra tools on most Macs,
  // especially Apple Silicon. This will usually resolve to 'N/A'.
  return run('sudo -n powermetrics -n 1 -i 1 --samplers smc 2>/dev/null | grep -i fan').then(out => {
    if (!out) return 'N/A';
    const match = out.match(/(\d+)\s*RPM/i);
    return match ? `${match[1]} RPM` : 'N/A';
  });
}

async function getUptime() {
  const d = await si.time();
  const totalMin = Math.floor(d.uptime / 60);
  const hrs = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  return `${hrs}h ${mins}m`;
}

async function getTopProcess() {
  const d = await si.processes();
  if (!d.list || !d.list.length) return null;
  const sorted = [...d.list].sort((a, b) => b.memRss - a.memRss);
  const top = sorted[0];
  return { name: top.name, memMb: Math.round(top.memRss / 1024) };
}

function getTimeUntil5pm() {
  const now = new Date();
  const target = new Date();
  target.setHours(17, 0, 0, 0);
  if (target < now) target.setDate(target.getDate() + 1);
  const diffMs = target - now;
  const hrs = Math.floor(diffMs / 3600000);
  const mins = Math.floor((diffMs % 3600000) / 60000);
  return `${hrs}h ${mins}m`;
}

function updateWordCount() {
  const text = clipboard.readText() || '';
  if (text && text !== lastClipboardText) {
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    wordCountTotal += words;
    lastClipboardText = text;
  }
  return wordCountTotal;
}

// ---- Metrics aggregation ----------------------------------------------------

async function collectMetrics(sessionKey) {
  const session = SESSIONS[sessionKey];
  const enabled = new Set(session.metrics);
  const out = { session: sessionKey, label: session.label, timestamp: Date.now() };
  const jobs = [];

  if (enabled.has('cpu')) jobs.push(si.currentLoad().then(d => { out.cpu = Math.round(d.currentLoad); }));
  if (enabled.has('ram')) jobs.push(si.mem().then(d => {
    out.ram = { usedPct: Math.round((d.active / d.total) * 100), usedGb: +(d.active / 1e9).toFixed(1), totalGb: +(d.total / 1e9).toFixed(1) };
  }));
  if (enabled.has('battery')) jobs.push(si.battery().then(d => {
    out.battery = { percent: d.percent, charging: d.isCharging, timeRemaining: d.timeRemaining };
  }));
  if (enabled.has('activeApp')) jobs.push(getActiveAppName().then(name => { out.activeApp = name; }));
  if (enabled.has('network')) jobs.push(si.networkStats().then(d => {
    const iface = d[0] || { rx_sec: 0, tx_sec: 0 };
    out.network = { downKbps: Math.round((iface.rx_sec || 0) / 1024), upKbps: Math.round((iface.tx_sec || 0) / 1024) };
  }));
  if (enabled.has('gpu')) jobs.push(si.graphics().then(d => {
    const gpu = d.controllers && d.controllers[0];
    out.gpu = gpu && gpu.utilizationGpu != null ? Math.round(gpu.utilizationGpu) : 'N/A';
  }));
  if (enabled.has('fanSpeed')) jobs.push(getFanSpeed().then(v => { out.fanSpeed = v; }));
  if (enabled.has('uptime')) jobs.push(getUptime().then(v => { out.uptime = v; }));
  if (enabled.has('topProcess')) jobs.push(getTopProcess().then(v => { out.topProcess = v; }));
  if (enabled.has('timeUntil5pm')) out.timeUntil5pm = getTimeUntil5pm();
  if (enabled.has('ping')) jobs.push(getPing().then(v => { out.ping = v; }));
  if (enabled.has('memoryPressure')) jobs.push(getMemoryPressure().then(v => { out.memoryPressure = v; }));
  if (enabled.has('fps')) out.fps = 'N/A (needs per-game overlay)';
  if (enabled.has('volume')) jobs.push(getVolume().then(v => { out.volume = v; }));
  if (enabled.has('music')) jobs.push(getMusicNowPlaying().then(v => { out.music = v; }));
  if (enabled.has('wordCount')) out.wordCount = updateWordCount();
  if (enabled.has('breakReminder')) {
    const minutesSinceBreak = Math.round((Date.now() - lastBreakAt) / 60000);
    out.breakReminder = { minutesSinceBreak, dueForBreak: minutesSinceBreak >= (session.breakIntervalMin || 60) };
  }

  await Promise.all(jobs);
  return out;
}

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  const tick = async () => {
    if (!win) return;
    const metrics = await collectMetrics(currentSessionKey);
    win.webContents.send('metrics-update', metrics);
  };
  tick();
  pollTimer = setInterval(tick, SESSIONS[currentSessionKey].refreshMs);
}

function positionWindowUnderTray() {
  const trayBounds = tray.getBounds();
  const winBounds = win.getBounds();
  const x = Math.round(trayBounds.x + trayBounds.width / 2 - winBounds.width / 2);
  const y = Math.round(trayBounds.y + trayBounds.height);
  win.setPosition(x, y, false);
}

function createWindow() {
  win = new BrowserWindow({
    width: 320,
    height: 480,
    show: false,
    frame: false,
    fullscreenable: false,
    resizable: false,
    skipTaskbar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile('index.html');
  win.on('blur', () => { if (win && !win.webContents.isDevToolsOpened()) win.hide(); });
}

function toggleWindow() {
  if (win.isVisible()) { win.hide(); } else { positionWindowUnderTray(); win.show(); win.focus(); }
}

function createTray() {
  const icon = nativeImage.createEmpty();
  tray = new Tray(icon);
  tray.setTitle('◐');
  tray.on('click', toggleWindow);
}

app.whenReady().then(() => { createWindow(); createTray(); startPolling(); });
app.on('window-all-closed', (e) => e.preventDefault());

// ---- IPC ---------------------------------------------------------------

ipcMain.handle('get-sessions', () => Object.entries(SESSIONS).map(([key, s]) => ({ key, label: s.label })));
ipcMain.handle('get-current-session', () => currentSessionKey);

ipcMain.on('switch-session', (event, sessionKey) => {
  if (!SESSIONS[sessionKey]) return;
  currentSessionKey = sessionKey;
  lastBreakAt = Date.now();
  startPolling();
});

ipcMain.on('reset-break-timer', () => { lastBreakAt = Date.now(); });

ipcMain.on('reset-word-count', () => {
  wordCountTotal = 0;
  lastClipboardText = clipboard.readText() || '';
});

ipcMain.on('update-tray-title', (event, title) => { if (tray) tray.setTitle(title); });
